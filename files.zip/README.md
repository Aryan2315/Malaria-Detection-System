# 🦟 Malaria Detector — Full Stack

AI-powered blood smear analysis using Claude's vision API, with a **secure Express backend** so your API key is never exposed to the browser.

---

## Project Structure

```
malaria-app/
├── backend/
│   ├── server.js          ← Express API server (keeps API key safe)
│   ├── package.json
│   └── .env.example       ← Copy → .env, add your ANTHROPIC_API_KEY
│
└── frontend/
    ├── src/
    │   ├── MalariaDetector.jsx   ← Main UI component (your original code, updated)
    │   ├── App.js
    │   └── index.js
    ├── public/index.html
    ├── package.json
    └── .env.example
```

---

## 🚀 Quick Start

### Step 1 — Backend

```bash
cd backend
npm install

# Create your environment file
cp .env.example .env
# Open .env and paste your Anthropic API key
```

Start the backend:
```bash
npm run dev    # development (auto-restarts on file changes)
# or
npm start      # production
```

Backend runs at **http://localhost:3001**

### Step 2 — Frontend

```bash
cd frontend
npm install
npm start
```

Frontend runs at **http://localhost:3000**
The `"proxy"` field in `package.json` automatically routes `/api/*` calls to your backend.

---

## 🔑 Environment Variables

### `backend/.env`

| Variable            | Required | Description                        | Default                     |
|---------------------|----------|------------------------------------|---------------------------  |
| `ANTHROPIC_API_KEY` | ✅ Yes   | Your Anthropic API key             | —                           |
| `PORT`              | No       | Port to run the server             | `3001`                      |
| `FRONTEND_URL`      | No       | Allowed CORS origin                | `http://localhost:3000`     |

### `frontend/.env` (production only)

| Variable              | Required       | Description                           |
|-----------------------|----------------|---------------------------------------|
| `REACT_APP_API_URL`   | Production only | Your deployed backend URL            |

> In **development**, you don't need this. The `"proxy"` in `package.json` handles it.

---

## 🔒 What Changed From the Original & Why

| Area | Original | This version |
|------|----------|--------------|
| **API calls** | Browser → Anthropic directly | Browser → Your backend → Anthropic |
| **API key location** | Hardcoded or in JS bundle (⚠️ exposed!) | Only in `backend/.env` (✅ safe) |
| **New: Disclaimer** | Not present | Medical disclaimer banner added |
| **New: History panel** | Not present | Session history of last 8 analyses |
| **Error messages** | Generic catch-all | Specific messages from backend |

---

## 📡 Backend API

### `GET /health`
Returns server status.
```json
{ "status": "ok", "timestamp": "..." }
```

### `POST /api/analyze`
Analyzes a blood smear image.

**Request:**
```json
{
  "imageBase64": "<base64 string>",
  "imageMime": "image/jpeg"
}
```

**Response:**
```json
{
  "result": {
    "prediction": "POSITIVE",
    "confidence": 94,
    "parasite_stage": "Ring stage",
    "cell_count_estimated": 1200,
    "parasitemia_level": "Moderate (1-5%)",
    "image_quality": "Good",
    "staining_quality": "Adequate",
    "findings_summary": "...",
    "recommendation": "..."
  }
}
```

---

## 🚢 Deploying to Production

**Backend** (e.g. Render, Railway, Fly.io):
1. Deploy the `backend/` folder
2. Set `ANTHROPIC_API_KEY` and `FRONTEND_URL` as environment variables

**Frontend** (e.g. Vercel, Netlify):
1. Deploy the `frontend/` folder
2. Set `REACT_APP_API_URL` to your deployed backend URL
3. Run build: `npm run build`

---

## ⚠️ Disclaimer

This tool is for **research and educational purposes only**.  
It is not a certified medical device. Always confirm results with a licensed pathologist.
