import MalariaDetector from "./MalariaDetector";

export default function App() {
  return <MalariaDetector />;
}
