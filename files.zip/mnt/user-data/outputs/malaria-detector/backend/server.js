const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors({ origin: process.env.FRONTEND_URL || "http://localhost:3000" }));
app.use(express.json({ limit: "20mb" })); // allow large base64 images

// ─── Health Check ─────────────────────────────────────────────────────────────
app.get("/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// ─── Malaria Analysis Endpoint ────────────────────────────────────────────────
app.post("/api/analyze", async (req, res) => {
  const { imageBase64, imageMime } = req.body;

  if (!imageBase64 || !imageMime) {
    return res.status(400).json({ error: "imageBase64 and imageMime are required." });
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: "API key not configured on server." });
  }

  const systemPrompt = `You are a deep learning CNN-based malaria detection system trained on blood smear microscopy images.
Analyze the uploaded image and respond ONLY with a valid JSON object (no markdown, no extra text).

Respond with exactly this structure:
{
  "prediction": "POSITIVE" or "NEGATIVE",
  "confidence": number between 0 and 100,
  "parasite_stage": "Ring stage" | "Trophozoite" | "Schizont" | "Gametocyte" | "None detected",
  "cell_count_estimated": number,
  "parasitemia_level": "High (>5%)" | "Moderate (1-5%)" | "Low (<1%)" | "None (0%)",
  "image_quality": "Good" | "Fair" | "Poor",
  "staining_quality": "Adequate" | "Overstained" | "Understained" | "N/A",
  "findings_summary": "2-3 sentence description of what was observed in the image",
  "recommendation": "One sentence clinical recommendation"
}

If the image is not a blood smear or microscopy image, set prediction to NEGATIVE with confidence 50 and note it in findings_summary.`;

  try {
    const anthropicResponse = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1000,
        system: systemPrompt,
        messages: [
          {
            role: "user",
            content: [
              {
                type: "image",
                source: { type: "base64", media_type: imageMime, data: imageBase64 },
              },
              {
                type: "text",
                text: "Analyze this blood smear image for malaria detection using CNN analysis.",
              },
            ],
          },
        ],
      }),
    });

    if (!anthropicResponse.ok) {
      const errBody = await anthropicResponse.text();
      console.error("Anthropic API error:", errBody);
      return res.status(502).json({ error: "Upstream AI service error.", detail: errBody });
    }

    const data = await anthropicResponse.json();
    const text = data.content?.map((b) => b.text || "").join("") || "";
    const clean = text.replace(/```json|```/g, "").trim();

    let parsed;
    try {
      parsed = JSON.parse(clean);
    } catch {
      return res.status(502).json({ error: "Failed to parse AI response as JSON.", raw: clean });
    }

    return res.json({ result: parsed });
  } catch (err) {
    console.error("Server error:", err);
    return res.status(500).json({ error: "Internal server error.", detail: err.message });
  }
});

app.listen(PORT, () => {
  console.log(`🩺 Malaria Detector backend running on http://localhost:${PORT}`);
});
