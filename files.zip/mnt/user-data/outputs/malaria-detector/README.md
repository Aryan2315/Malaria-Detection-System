# 🦟 Malaria Detector — Full Stack

AI-powered malaria detection from blood smear images, using Claude's vision API via a secure Express backend.

---

## Project Structure

```
malaria-detector/
├── backend/
│   ├── server.js          ← Express API server
│   ├── package.json
│   └── .env.example       ← Copy to .env and fill in your API key
└── frontend/
    ├── src/
    │   └── MalariaDetector.jsx   ← Main React component
    ├── package.json
    └── .env.example
```

---

## 🚀 Getting Started

### 1. Backend Setup

```bash
cd backend
npm install

# Create your .env file
cp .env.example .env
# Edit .env and add your ANTHROPIC_API_KEY
```

Start the backend:
```bash
npm run dev     # development (with nodemon auto-reload)
npm start       # production
```

The server runs on **http://localhost:3001** by default.

### 2. Frontend Setup

```bash
cd frontend
npm install
npm start
```

The React app runs on **http://localhost:3000** and proxies `/api/*` to the backend automatically (via `"proxy"` in package.json).

---

## 🔑 Environment Variables

### Backend (`backend/.env`)

| Variable          | Description                              | Default                    |
|-------------------|------------------------------------------|----------------------------|
| `ANTHROPIC_API_KEY` | Your Anthropic API key (**required**)  | —                          |
| `PORT`            | Port to run the server on                | `3001`                     |
| `FRONTEND_URL`    | Allowed CORS origin                      | `http://localhost:3000`    |

### Frontend (`frontend/.env`)

| Variable                | Description                         | Default                    |
|-------------------------|-------------------------------------|----------------------------|
| `REACT_APP_BACKEND_URL` | Backend URL (for production builds) | `http://localhost:3001`    |

> In **development**, the `"proxy"` field in `frontend/package.json` handles routing automatically. You only need `REACT_APP_BACKEND_URL` for production.

---

## 🔒 Key Security Improvement

The original code called the Anthropic API **directly from the browser**, which would expose your API key to anyone who inspects network traffic or your JS bundle.

This version fixes that:
- ✅ The API key lives only in `backend/.env` — never sent to the client
- ✅ The frontend calls `/api/analyze` on your own backend
- ✅ The backend forwards the request to Anthropic with the key server-side

---

## 📡 API Endpoints

### `GET /health`
Returns server status.

### `POST /api/analyze`
Analyzes a blood smear image.

**Request body:**
```json
{
  "imageBase64": "<base64 encoded image>",
  "imageMime": "image/jpeg"
}
```

**Response:**
```json
{
  "result": {
    "prediction": "POSITIVE" | "NEGATIVE",
    "confidence": 94,
    "parasite_stage": "Ring stage",
    "cell_count_estimated": 1200,
    "parasitemia_level": "Moderate (1-5%)",
    "image_quality": "Good",
    "staining_quality": "Adequate",
    "findings_summary": "...",
    "recommendation": "..."
  }
}
```

---

## ⚠️ Disclaimer

This tool is for **research and educational purposes only**. It is not a certified medical device. Always confirm results with a licensed pathologist.
