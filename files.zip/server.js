/**
 * Malaria Detector — Backend API Server
 * 
 * WHY THIS EXISTS:
 * The original frontend called the Anthropic API directly from the browser.
 * That exposes your secret API key to anyone who opens DevTools.
 * This server acts as a secure proxy — the key lives only here, in .env.
 */

const express = require("express");
const cors = require("cors");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 3001;

// ── Middleware ─────────────────────────────────────────────────────────────────
app.use(cors({
  origin: process.env.FRONTEND_URL || "http://localhost:3000",
  methods: ["GET", "POST"],
}));
app.use(express.json({ limit: "25mb" })); // large enough for base64 images

// ── Health check ───────────────────────────────────────────────────────────────
app.get("/health", (_req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// ── Main analysis endpoint ─────────────────────────────────────────────────────
app.post("/api/analyze", async (req, res) => {
  const { imageBase64, imageMime } = req.body;

  // Validate input
  if (!imageBase64 || typeof imageBase64 !== "string") {
    return res.status(400).json({ error: "Missing or invalid imageBase64 field." });
  }
  if (!imageMime || !imageMime.startsWith("image/")) {
    return res.status(400).json({ error: "Missing or invalid imageMime field." });
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    console.error("ANTHROPIC_API_KEY is not set in environment.");
    return res.status(500).json({ error: "Server is not configured with an API key." });
  }

  const systemPrompt = `You are a deep learning CNN-based malaria detection system trained on blood smear microscopy images. 
Analyze the uploaded image and respond ONLY with a valid JSON object (no markdown, no extra text).

Respond with exactly this structure:
{
  "prediction": "POSITIVE" or "NEGATIVE",
  "confidence": number between 0 and 100,
  "parasite_stage": "Ring stage" | "Trophozoite" | "Schizont" | "Gametocyte" | "None detected",
  "cell_count_estimated": number,
  "parasitemia_level": "High (>5%)" | "Moderate (1-5%)" | "Low (<1%)" | "None (0%)",
  "image_quality": "Good" | "Fair" | "Poor",
  "staining_quality": "Adequate" | "Overstained" | "Understained" | "N/A",
  "findings_summary": "2-3 sentence description of what was observed in the image",
  "recommendation": "One sentence clinical recommendation"
}

If the image is not a blood smear or microscopy image, set prediction to NEGATIVE with confidence 50 and note it in findings_summary.`;

  try {
    const anthropicRes = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1000,
        system: systemPrompt,
        messages: [{
          role: "user",
          content: [
            {
              type: "image",
              source: { type: "base64", media_type: imageMime, data: imageBase64 },
            },
            {
              type: "text",
              text: "Analyze this blood smear image for malaria detection using CNN analysis.",
            },
          ],
        }],
      }),
    });

    if (!anthropicRes.ok) {
      const errText = await anthropicRes.text();
      console.error("Anthropic API error:", anthropicRes.status, errText);
      return res.status(502).json({
        error: `Upstream API error (${anthropicRes.status}). Please try again.`,
      });
    }

    const data = await anthropicRes.json();
    const rawText = data.content?.map((b) => b.text || "").join("") || "";
    const cleaned = rawText.replace(/```json|```/g, "").trim();

    let result;
    try {
      result = JSON.parse(cleaned);
    } catch {
      console.error("Failed to parse AI response as JSON:", cleaned);
      return res.status(502).json({
        error: "AI returned an unexpected response format. Please try again.",
      });
    }

    return res.json({ result });

  } catch (err) {
    console.error("Unexpected server error:", err);
    return res.status(500).json({ error: "An unexpected error occurred. Please try again." });
  }
});

// ── Start ──────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🩺 Malaria Detector Backend`);
  console.log(`   Running at: http://localhost:${PORT}`);
  console.log(`   Health:     http://localhost:${PORT}/health\n`);
});
